Please make sure that your folder follows this following tree: 
	|--> haarcascade_frontalface_default.xml
	|--> Face_Detection_&_Identification.ipynb
	|--> data
		|-->Group
		|	|--> [group image]
		|-->Angela
		|	|--> [Angela images]
		|-->Kevin
		|	|--> [Kevin images]
		|-->Oscar
			|--> [Oscar images]